package com.devxnow.smartplug.lib.font.widget;

import android.content.Context;
import android.util.AttributeSet;

import com.devxnow.smartplug.R;

import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: AvenirDemiTextView.kt */

/* loaded from: classes3.dex */
public class AvenirDemiTextView extends TypefaceTextView {
    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public AvenirDemiTextView(Context context) {
        this(context, null, 0, 6, null);
        Intrinsics.checkNotNullParameter(context, "context");
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public AvenirDemiTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0, 4, null);
        Intrinsics.checkNotNullParameter(context, "context");
    }

    public /* synthetic */ AvenirDemiTextView(Context context, AttributeSet attributeSet, int i, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(context, (i2 & 2) != 0 ? null : attributeSet, (i2 & 4) != 0 ? 0 : i);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AvenirDemiTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, R.font.avenir_next_ltpro_demi, attributeSet, i);
        Intrinsics.checkNotNullParameter(context, "context");
    }
}
