package com.devxnow.smartplug.lib.font.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatTextView;

import com.devxnow.smartplug.lib.font.ViewsKt;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* compiled from: TypefaceTextView.kt */
/* loaded from: classes3.dex */
public abstract class TypefaceTextView extends AppCompatTextView {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public TypefaceTextView(Context context, int i, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        Intrinsics.checkNotNullParameter(context, "context");
        setTypeface(ViewsKt.getFont(this, i));
    }

    @Override // android.widget.TextView
    public void setTextAppearance(int i) {
        Typeface typeface = getTypeface();
        super.setTextAppearance(i);
        setTypeface(typeface);
    }
}
