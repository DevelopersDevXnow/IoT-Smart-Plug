package com.devxnow.smartplug.lib.font;

import android.graphics.Typeface;
import android.view.View;
import androidx.core.content.res.ResourcesCompat;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

public final class ViewsKt {
    public static final Typeface getFont(View view, int i) {
        Intrinsics.checkNotNullParameter(view, "<this>");
        if (view.isInEditMode()) {
            Typeface DEFAULT = Typeface.DEFAULT;
            Intrinsics.checkNotNullExpressionValue(DEFAULT, "DEFAULT");
            return DEFAULT;
        }
        Typeface font = ResourcesCompat.getFont(view.getContext(), i);
        Intrinsics.checkNotNull(font);
        return font;
    }
}
